
#include "ZGBMain.h"

extern const INT8 sine_wave[256];
