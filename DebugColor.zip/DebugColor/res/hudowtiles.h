#ifndef TILES_hudowtiles_H
#define TILES_hudowtiles_H
#define hudowtilesCGBPal0c0 32767
#define hudowtilesCGBPal0c1 8935
#define hudowtilesCGBPal0c2 6596
#define hudowtilesCGBPal0c3 0

#define hudowtilesCGBPal1c0 32767
#define hudowtilesCGBPal1c1 8863
#define hudowtilesCGBPal1c2 30
#define hudowtilesCGBPal1c3 85

#include "TilesInfo.h"
extern const void __bank_hudowtiles;
extern struct TilesInfo hudowtiles;
#endif
