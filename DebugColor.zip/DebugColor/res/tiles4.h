#ifndef TILES_tiles4_H
#define TILES_tiles4_H
#define tiles4CGBPal0c0 32767
#define tiles4CGBPal0c1 8935
#define tiles4CGBPal0c2 6596
#define tiles4CGBPal0c3 5344

#define tiles4CGBPal1c0 23551
#define tiles4CGBPal1c1 5053
#define tiles4CGBPal1c2 3871
#define tiles4CGBPal1c3 13346

#define tiles4CGBPal2c0 32767
#define tiles4CGBPal2c1 23254
#define tiles4CGBPal2c2 247
#define tiles4CGBPal2c3 0

#define tiles4CGBPal3c0 32767
#define tiles4CGBPal3c1 31636
#define tiles4CGBPal3c2 32067
#define tiles4CGBPal3c3 1057

#define tiles4CGBPal4c0 6076
#define tiles4CGBPal4c1 799
#define tiles4CGBPal4c2 470
#define tiles4CGBPal4c3 5344

#define tiles4CGBPal5c0 32767
#define tiles4CGBPal5c1 799
#define tiles4CGBPal5c2 8476
#define tiles4CGBPal5c3 5344

#define tiles4CGBPal6c0 32767
#define tiles4CGBPal6c1 8991
#define tiles4CGBPal6c2 6596
#define tiles4CGBPal6c3 8476

#include "TilesInfo.h"
extern const void __bank_tiles4;
extern struct TilesInfo tiles4;
#endif
