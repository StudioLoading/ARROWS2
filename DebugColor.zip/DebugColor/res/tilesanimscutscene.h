#ifndef TILES_tilesanimscutscene_H
#define TILES_tilesanimscutscene_H
#define tilesanimscutsceneCGBPal0c0 6076
#define tilesanimscutsceneCGBPal0c1 8935
#define tilesanimscutsceneCGBPal0c2 6596
#define tilesanimscutsceneCGBPal0c3 5344

#define tilesanimscutsceneCGBPal1c0 32767
#define tilesanimscutsceneCGBPal1c1 21140
#define tilesanimscutsceneCGBPal1c2 536
#define tilesanimscutsceneCGBPal1c3 0

#define tilesanimscutsceneCGBPal2c0 32767
#define tilesanimscutsceneCGBPal2c1 26425
#define tilesanimscutsceneCGBPal2c2 32054
#define tilesanimscutsceneCGBPal2c3 17413

#include "TilesInfo.h"
extern const void __bank_tilesanimscutscene;
extern struct TilesInfo tilesanimscutscene;
#endif
