#ifndef TILES_hudpltiles_H
#define TILES_hudpltiles_H
#define hudpltilesCGBPal0c0 32767
#define hudpltilesCGBPal0c1 8935
#define hudpltilesCGBPal0c2 6596
#define hudpltilesCGBPal0c3 0

#define hudpltilesCGBPal1c0 32767
#define hudpltilesCGBPal1c1 21140
#define hudpltilesCGBPal1c2 12684
#define hudpltilesCGBPal1c3 0

#define hudpltilesCGBPal2c0 32767
#define hudpltilesCGBPal2c1 21140
#define hudpltilesCGBPal2c2 536
#define hudpltilesCGBPal2c3 0

#define hudpltilesCGBPal3c0 32767
#define hudpltilesCGBPal3c1 8863
#define hudpltilesCGBPal3c2 30
#define hudpltilesCGBPal3c3 85

#include "TilesInfo.h"
extern const void __bank_hudpltiles;
extern struct TilesInfo hudpltiles;
#endif
