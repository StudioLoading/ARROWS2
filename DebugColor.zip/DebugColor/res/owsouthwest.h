#ifndef MAP_owsouthwest_H
#define MAP_owsouthwest_H
#define owsouthwestWidth 56
#define owsouthwestHeight 56
#include "MapInfo.h"
extern unsigned char bank_owsouthwest;
extern struct MapInfo owsouthwest;
#endif
