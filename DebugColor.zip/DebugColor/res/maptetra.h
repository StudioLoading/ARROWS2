#ifndef MAP_maptetra_H
#define MAP_maptetra_H
#define maptetraWidth 100
#define maptetraHeight 50
#include "MapInfo.h"
extern unsigned char bank_maptetra;
extern struct MapInfo maptetra;
#endif
