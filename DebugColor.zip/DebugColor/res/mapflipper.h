#ifndef MAP_mapflipper_H
#define MAP_mapflipper_H
#define mapflipperWidth 40
#define mapflipperHeight 40
#include "MapInfo.h"
extern unsigned char bank_mapflipper;
extern struct MapInfo mapflipper;
#endif
