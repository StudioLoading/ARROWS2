#ifndef TILES_tilestitlescreen_H
#define TILES_tilestitlescreen_H
#define tilestitlescreenCGBPal0c0 23519
#define tilestitlescreenCGBPal0c1 11115
#define tilestitlescreenCGBPal0c2 672
#define tilestitlescreenCGBPal0c3 192

#define tilestitlescreenCGBPal1c0 23519
#define tilestitlescreenCGBPal1c1 767
#define tilestitlescreenCGBPal1c2 2654
#define tilestitlescreenCGBPal1c3 2430

#define tilestitlescreenCGBPal2c0 23519
#define tilestitlescreenCGBPal2c1 9983
#define tilestitlescreenCGBPal2c2 6596
#define tilestitlescreenCGBPal2c3 0

#define tilestitlescreenCGBPal3c0 23519
#define tilestitlescreenCGBPal3c1 6596
#define tilestitlescreenCGBPal3c2 1488
#define tilestitlescreenCGBPal3c3 0

#define tilestitlescreenCGBPal4c0 23519
#define tilestitlescreenCGBPal4c1 9983
#define tilestitlescreenCGBPal4c2 1488
#define tilestitlescreenCGBPal4c3 0

#include "TilesInfo.h"
extern const void __bank_tilestitlescreen;
extern struct TilesInfo tilestitlescreen;
#endif
