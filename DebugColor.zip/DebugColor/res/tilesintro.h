#ifndef TILES_tilesintro_H
#define TILES_tilesintro_H
#define tilesintroCGBPal0c0 31710
#define tilesintroCGBPal0c1 6047
#define tilesintroCGBPal0c2 8456
#define tilesintroCGBPal0c3 5344

#include "TilesInfo.h"
extern const void __bank_tilesintro;
extern struct TilesInfo tilesintro;
#endif
