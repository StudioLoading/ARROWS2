#ifndef MAP_hudpl_H
#define MAP_hudpl_H
#define hudplWidth 20
#define hudplHeight 3
#include "MapInfo.h"
extern unsigned char bank_hudpl;
extern struct MapInfo hudpl;
#endif
