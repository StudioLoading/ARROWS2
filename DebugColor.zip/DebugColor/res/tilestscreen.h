#ifndef TILES_tilestscreen_H
#define TILES_tilestscreen_H
#define tilestscreenCGBPal0c0 23519
#define tilestscreenCGBPal0c1 11115
#define tilestscreenCGBPal0c2 672
#define tilestscreenCGBPal0c3 192

#define tilestscreenCGBPal1c0 23519
#define tilestscreenCGBPal1c1 9983
#define tilestscreenCGBPal1c2 2654
#define tilestscreenCGBPal1c3 2430

#include "TilesInfo.h"
extern const void __bank_tilestscreen;
extern struct TilesInfo tilestscreen;
#endif
