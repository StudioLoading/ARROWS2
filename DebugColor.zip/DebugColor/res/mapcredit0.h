#ifndef MAP_mapcredit0_H
#define MAP_mapcredit0_H
#define mapcredit0Width 20
#define mapcredit0Height 24
#include "MapInfo.h"
extern unsigned char bank_mapcredit0;
extern struct MapInfo mapcredit0;
#endif
