#ifndef MAP_exzoomap0_H
#define MAP_exzoomap0_H
#define exzoomap0Width 80
#define exzoomap0Height 20
#include "MapInfo.h"
extern unsigned char bank_exzoomap0;
extern struct MapInfo exzoomap0;
#endif
