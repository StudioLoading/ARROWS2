#ifndef TILES_tilesdiagcrossbow_H
#define TILES_tilesdiagcrossbow_H
#define tilesdiagcrossbowCGBPal0c0 32767
#define tilesdiagcrossbowCGBPal0c1 8935
#define tilesdiagcrossbowCGBPal0c2 6596
#define tilesdiagcrossbowCGBPal0c3 0

#define tilesdiagcrossbowCGBPal1c0 32767
#define tilesdiagcrossbowCGBPal1c1 2815
#define tilesdiagcrossbowCGBPal1c2 9752
#define tilesdiagcrossbowCGBPal1c3 0

#include "TilesInfo.h"
extern const void __bank_tilesdiagcrossbow;
extern struct TilesInfo tilesdiagcrossbow;
#endif
