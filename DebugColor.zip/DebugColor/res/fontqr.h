#ifndef TILES_fontqr_H
#define TILES_fontqr_H
#include "TilesInfo.h"
extern const void __bank_fontqr;
extern struct TilesInfo fontqr;
#endif
