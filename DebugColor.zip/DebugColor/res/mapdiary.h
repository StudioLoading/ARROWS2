#ifndef MAP_mapdiary_H
#define MAP_mapdiary_H
#define mapdiaryWidth 40
#define mapdiaryHeight 18
#include "MapInfo.h"
extern unsigned char bank_mapdiary;
extern struct MapInfo mapdiary;
#endif
