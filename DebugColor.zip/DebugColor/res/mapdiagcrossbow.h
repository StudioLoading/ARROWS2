#ifndef MAP_mapdiagcrossbow_H
#define MAP_mapdiagcrossbow_H
#define mapdiagcrossbowWidth 20
#define mapdiagcrossbowHeight 5
#include "MapInfo.h"
extern unsigned char bank_mapdiagcrossbow;
extern struct MapInfo mapdiagcrossbow;
#endif
