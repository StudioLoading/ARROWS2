#ifndef TILES_tdiagcrossbowempty_H
#define TILES_tdiagcrossbowempty_H
#define tdiagcrossbowemptyCGBPal0c0 32767
#define tdiagcrossbowemptyCGBPal0c1 8935
#define tdiagcrossbowemptyCGBPal0c2 6596
#define tdiagcrossbowemptyCGBPal0c3 0

#define tdiagcrossbowemptyCGBPal1c0 32767
#define tdiagcrossbowemptyCGBPal1c1 2815
#define tdiagcrossbowemptyCGBPal1c2 9752
#define tdiagcrossbowemptyCGBPal1c3 0

#include "TilesInfo.h"
extern const void __bank_tdiagcrossbowempty;
extern struct TilesInfo tdiagcrossbowempty;
#endif
