#ifndef TILES_tilescredit_H
#define TILES_tilescredit_H
#define tilescreditCGBPal0c0 32767
#define tilescreditCGBPal0c1 19026
#define tilescreditCGBPal0c2 10570
#define tilescreditCGBPal0c3 0

#include "TilesInfo.h"
extern const void __bank_tilescredit;
extern struct TilesInfo tilescredit;
#endif
