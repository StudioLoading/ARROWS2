#ifndef TILES_tilestetra_H
#define TILES_tilestetra_H
#define tilestetraCGBPal0c0 32767
#define tilestetraCGBPal0c1 8935
#define tilestetraCGBPal0c2 6596
#define tilestetraCGBPal0c3 0

#define tilestetraCGBPal1c0 32767
#define tilestetraCGBPal1c1 19026
#define tilestetraCGBPal1c2 10570
#define tilestetraCGBPal1c3 0

#define tilestetraCGBPal2c0 32767
#define tilestetraCGBPal2c1 32660
#define tilestetraCGBPal2c2 22752
#define tilestetraCGBPal2c3 0

#define tilestetraCGBPal3c0 32767
#define tilestetraCGBPal3c1 8863
#define tilestetraCGBPal3c2 30
#define tilestetraCGBPal3c3 85

#define tilestetraCGBPal4c0 32767
#define tilestetraCGBPal4c1 21140
#define tilestetraCGBPal4c2 16896
#define tilestetraCGBPal4c3 4332

#include "TilesInfo.h"
extern const void __bank_tilestetra;
extern struct TilesInfo tilestetra;
#endif
