#ifndef TILES_font_H
#define TILES_font_H
#include "TilesInfo.h"
extern const void __bank_font;
extern struct TilesInfo font;
#endif
