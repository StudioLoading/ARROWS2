#ifndef TILES_tilesanimsmapworld_H
#define TILES_tilesanimsmapworld_H
#define tilesanimsmapworldCGBPal0c0 32767
#define tilesanimsmapworldCGBPal0c1 11115
#define tilesanimsmapworldCGBPal0c2 384
#define tilesanimsmapworldCGBPal0c3 320

#define tilesanimsmapworldCGBPal1c0 32767
#define tilesanimsmapworldCGBPal1c1 767
#define tilesanimsmapworldCGBPal1c2 1598
#define tilesanimsmapworldCGBPal1c3 2429

#define tilesanimsmapworldCGBPal2c0 32767
#define tilesanimsmapworldCGBPal2c1 29596
#define tilesanimsmapworldCGBPal2c2 21140
#define tilesanimsmapworldCGBPal2c3 8456

#define tilesanimsmapworldCGBPal3c0 32767
#define tilesanimsmapworldCGBPal3c1 32042
#define tilesanimsmapworldCGBPal3c2 502
#define tilesanimsmapworldCGBPal3c3 31574

#define tilesanimsmapworldCGBPal4c0 7165
#define tilesanimsmapworldCGBPal4c1 19026
#define tilesanimsmapworldCGBPal4c2 21140
#define tilesanimsmapworldCGBPal4c3 0

#define tilesanimsmapworldCGBPal5c0 32767
#define tilesanimsmapworldCGBPal5c1 31572
#define tilesanimsmapworldCGBPal5c2 32326
#define tilesanimsmapworldCGBPal5c3 22784

#include "TilesInfo.h"
extern const void __bank_tilesanimsmapworld;
extern struct TilesInfo tilesanimsmapworld;
#endif
