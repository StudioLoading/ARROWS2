#ifndef MAP_mapintro_H
#define MAP_mapintro_H
#define mapintroWidth 20
#define mapintroHeight 115
#include "MapInfo.h"
extern unsigned char bank_mapintro;
extern struct MapInfo mapintro;
#endif
