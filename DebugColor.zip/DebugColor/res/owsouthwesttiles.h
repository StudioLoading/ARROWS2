#ifndef TILES_owsouthwesttiles_H
#define TILES_owsouthwesttiles_H
#define owsouthwesttilesCGBPal0c0 32767
#define owsouthwesttilesCGBPal0c1 8935
#define owsouthwesttilesCGBPal0c2 6596
#define owsouthwesttilesCGBPal0c3 0

#define owsouthwesttilesCGBPal1c0 32767
#define owsouthwesttilesCGBPal1c1 21140
#define owsouthwesttilesCGBPal1c2 12684
#define owsouthwesttilesCGBPal1c3 0

#define owsouthwesttilesCGBPal2c0 32767
#define owsouthwesttilesCGBPal2c1 21140
#define owsouthwesttilesCGBPal2c2 536
#define owsouthwesttilesCGBPal2c3 0

#define owsouthwesttilesCGBPal3c0 32767
#define owsouthwesttilesCGBPal3c1 2815
#define owsouthwesttilesCGBPal3c2 9752
#define owsouthwesttilesCGBPal3c3 0

#define owsouthwesttilesCGBPal4c0 32767
#define owsouthwesttilesCGBPal4c1 32660
#define owsouthwesttilesCGBPal4c2 32131
#define owsouthwesttilesCGBPal4c3 0

#define owsouthwesttilesCGBPal5c0 32767
#define owsouthwesttilesCGBPal5c1 21140
#define owsouthwesttilesCGBPal5c2 16896
#define owsouthwesttilesCGBPal5c3 4332

#include "TilesInfo.h"
extern const void __bank_owsouthwesttiles;
extern struct TilesInfo owsouthwesttiles;
#endif
