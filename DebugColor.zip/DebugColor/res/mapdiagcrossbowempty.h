#ifndef MAP_mapdiagcrossbowempty_H
#define MAP_mapdiagcrossbowempty_H
#define mapdiagcrossbowemptyWidth 20
#define mapdiagcrossbowemptyHeight 5
#include "MapInfo.h"
extern unsigned char bank_mapdiagcrossbowempty;
extern struct MapInfo mapdiagcrossbowempty;
#endif
