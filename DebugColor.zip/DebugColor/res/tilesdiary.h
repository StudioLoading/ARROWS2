#ifndef TILES_tilesdiary_H
#define TILES_tilesdiary_H
#define tilesdiaryCGBPal0c0 32767
#define tilesdiaryCGBPal0c1 21140
#define tilesdiaryCGBPal0c2 16896
#define tilesdiaryCGBPal0c3 4332

#include "TilesInfo.h"
extern const void __bank_tilesdiary;
extern struct TilesInfo tilesdiary;
#endif
