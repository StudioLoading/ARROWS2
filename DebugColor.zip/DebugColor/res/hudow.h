#ifndef MAP_hudow_H
#define MAP_hudow_H
#define hudowWidth 20
#define hudowHeight 5
#include "MapInfo.h"
extern unsigned char bank_hudow;
extern struct MapInfo hudow;
#endif
