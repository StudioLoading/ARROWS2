#ifndef TILES_tilesanims_H
#define TILES_tilesanims_H
#define tilesanimsCGBPal0c0 32767
#define tilesanimsCGBPal0c1 8935
#define tilesanimsCGBPal0c2 6596
#define tilesanimsCGBPal0c3 0

#define tilesanimsCGBPal1c0 32767
#define tilesanimsCGBPal1c1 21140
#define tilesanimsCGBPal1c2 12684
#define tilesanimsCGBPal1c3 0

#define tilesanimsCGBPal2c0 32767
#define tilesanimsCGBPal2c1 21140
#define tilesanimsCGBPal2c2 536
#define tilesanimsCGBPal2c3 0

#include "TilesInfo.h"
extern const void __bank_tilesanims;
extern struct TilesInfo tilesanims;
#endif
