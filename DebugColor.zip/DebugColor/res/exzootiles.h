#ifndef TILES_exzootiles_H
#define TILES_exzootiles_H
#define exzootilesCGBPal0c0 32767
#define exzootilesCGBPal0c1 8935
#define exzootilesCGBPal0c2 6596
#define exzootilesCGBPal0c3 0

#define exzootilesCGBPal1c0 32767
#define exzootilesCGBPal1c1 21140
#define exzootilesCGBPal1c2 12684
#define exzootilesCGBPal1c3 0

#define exzootilesCGBPal2c0 32767
#define exzootilesCGBPal2c1 21140
#define exzootilesCGBPal2c2 536
#define exzootilesCGBPal2c3 0

#include "TilesInfo.h"
extern const void __bank_exzootiles;
extern struct TilesInfo exzootiles;
#endif
