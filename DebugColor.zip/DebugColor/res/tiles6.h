#ifndef TILES_tiles6_H
#define TILES_tiles6_H
#define tiles6CGBPal0c0 32767
#define tiles6CGBPal0c1 21140
#define tiles6CGBPal0c2 536
#define tiles6CGBPal0c3 0

#define tiles6CGBPal1c0 32767
#define tiles6CGBPal1c1 26425
#define tiles6CGBPal1c2 32054
#define tiles6CGBPal1c3 17413

#define tiles6CGBPal2c0 6076
#define tiles6CGBPal2c1 32660
#define tiles6CGBPal2c2 22915
#define tiles6CGBPal2c3 0

#define tiles6CGBPal3c0 32767
#define tiles6CGBPal3c1 32660
#define tiles6CGBPal3c2 32131
#define tiles6CGBPal3c3 0

#define tiles6CGBPal4c0 32767
#define tiles6CGBPal4c1 21140
#define tiles6CGBPal4c2 16896
#define tiles6CGBPal4c3 4332

#include "TilesInfo.h"
extern const void __bank_tiles6;
extern struct TilesInfo tiles6;
#endif
