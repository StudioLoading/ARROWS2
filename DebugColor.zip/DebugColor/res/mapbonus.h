#ifndef MAP_mapbonus_H
#define MAP_mapbonus_H
#define mapbonusWidth 30
#define mapbonusHeight 30
#include "MapInfo.h"
extern unsigned char bank_mapbonus;
extern struct MapInfo mapbonus;
#endif
