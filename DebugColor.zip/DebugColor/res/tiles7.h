#ifndef TILES_tiles7_H
#define TILES_tiles7_H
#define tiles7CGBPal0c0 32767
#define tiles7CGBPal0c1 8935
#define tiles7CGBPal0c2 6596
#define tiles7CGBPal0c3 0

#define tiles7CGBPal1c0 32767
#define tiles7CGBPal1c1 21140
#define tiles7CGBPal1c2 12684
#define tiles7CGBPal1c3 0

#define tiles7CGBPal2c0 32767
#define tiles7CGBPal2c1 21140
#define tiles7CGBPal2c2 536
#define tiles7CGBPal2c3 0

#define tiles7CGBPal3c0 32767
#define tiles7CGBPal3c1 2815
#define tiles7CGBPal3c2 9752
#define tiles7CGBPal3c3 0

#define tiles7CGBPal4c0 10206
#define tiles7CGBPal4c1 32660
#define tiles7CGBPal4c2 22752
#define tiles7CGBPal4c3 0

#define tiles7CGBPal5c0 32767
#define tiles7CGBPal5c1 8863
#define tiles7CGBPal5c2 30
#define tiles7CGBPal5c3 85

#define tiles7CGBPal6c0 32767
#define tiles7CGBPal6c1 32660
#define tiles7CGBPal6c2 32131
#define tiles7CGBPal6c3 0

#define tiles7CGBPal7c0 32767
#define tiles7CGBPal7c1 21140
#define tiles7CGBPal7c2 16896
#define tiles7CGBPal7c3 4332

#include "TilesInfo.h"
extern const void __bank_tiles7;
extern struct TilesInfo tiles7;
#endif
