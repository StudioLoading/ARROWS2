#ifndef TILES_tilesanimcredit_H
#define TILES_tilesanimcredit_H
#define tilesanimcreditCGBPal0c0 32767
#define tilesanimcreditCGBPal0c1 8935
#define tilesanimcreditCGBPal0c2 6596
#define tilesanimcreditCGBPal0c3 0

#define tilesanimcreditCGBPal1c0 32767
#define tilesanimcreditCGBPal1c1 21140
#define tilesanimcreditCGBPal1c2 12684
#define tilesanimcreditCGBPal1c3 0

#include "TilesInfo.h"
extern const void __bank_tilesanimcredit;
extern struct TilesInfo tilesanimcredit;
#endif
