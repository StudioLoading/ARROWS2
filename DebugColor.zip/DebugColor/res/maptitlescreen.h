#ifndef MAP_maptitlescreen_H
#define MAP_maptitlescreen_H
#define maptitlescreenWidth 140
#define maptitlescreenHeight 18
#include "MapInfo.h"
extern unsigned char bank_maptitlescreen;
extern struct MapInfo maptitlescreen;
#endif
