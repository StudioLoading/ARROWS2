#ifndef TILES_fontbw_H
#define TILES_fontbw_H
#define fontbwCGBPal0c0 32767
#define fontbwCGBPal0c1 8935
#define fontbwCGBPal0c2 6596
#define fontbwCGBPal0c3 0

#define fontbwCGBPal1c0 32767
#define fontbwCGBPal1c1 21140
#define fontbwCGBPal1c2 12684
#define fontbwCGBPal1c3 0

#include "TilesInfo.h"
extern const void __bank_fontbw;
extern struct TilesInfo fontbw;
#endif
