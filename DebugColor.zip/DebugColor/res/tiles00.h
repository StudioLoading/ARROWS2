#ifndef TILES_tiles00_H
#define TILES_tiles00_H
#define tiles00CGBPal0c0 32767
#define tiles00CGBPal0c1 8935
#define tiles00CGBPal0c2 6596
#define tiles00CGBPal0c3 5344

#define tiles00CGBPal1c0 32767
#define tiles00CGBPal1c1 5053
#define tiles00CGBPal1c2 3871
#define tiles00CGBPal1c3 247

#include "TilesInfo.h"
extern const void __bank_tiles00;
extern struct TilesInfo tiles00;
#endif
